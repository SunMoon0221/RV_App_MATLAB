#!/bin/bash
cd "$(dirname "$0")"
APP_NAME="MyAppInstaller.app"

if [ ! -d "$APP_NAME" ]; then
  echo "Could not find $APP_NAME in this folder."
  echo "Make sure the .app is inside: $(pwd)"
  exit 1
fi

echo "Removing quarantine flag..."
xattr -dr com.apple.quarantine "$APP_NAME"

echo "Launching installer..."
open "$APP_NAME"

echo "Done! You can close this window."
